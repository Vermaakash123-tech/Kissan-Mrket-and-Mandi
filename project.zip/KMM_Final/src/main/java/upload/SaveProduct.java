package upload;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Part;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.PrintWriter;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;

import connect.DbManager;
/**
 * Servlet implementation class SaveProduct
 */
@WebServlet("/SaveProduct")
@MultipartConfig
public class SaveProduct extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public SaveProduct() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter out=response.getWriter();
		String region=request.getParameter("region");
		String catname=request.getParameter("catname");
		String pname=request.getParameter("pname");
		int buy_price=Integer.parseInt(request.getParameter("buy_price"));
		int sell_price=Integer.parseInt(request.getParameter("sell_price"));
		Part filepart=request.getPart("pimage");
		String filename=filepart.getSubmittedFileName();
		InputStream filecontent=filepart.getInputStream();
		String uploadPath = "D:/advanceJava/KMM_Final/src/main/webapp/products/";
		 // Create the directory if it doesn't exist
        File uploadDir = new File(uploadPath);
        if (!uploadDir.exists()) {
            uploadDir.mkdir();
        }
        // File path to save the file
        String filePath = uploadPath + filename;
        DbManager dm=new DbManager();
		String query="insert into product(region, catname, pname, pimage, buy_price, sell_price) values('"+region+"','"+catname+"','"+pname+"','"+filename+"','"+buy_price+"','"+sell_price+"')";
		if(dm.insertUpdateDelete(query)==true)
		{
			try (InputStream fileContent = filepart.getInputStream()) {
	            Files.copy(fileContent, Paths.get(filePath), StandardCopyOption.REPLACE_EXISTING);
	        }

			out.print("<script>alert('Product is saved');window.location.href='adminzone/manageproduct.jsp';</script>");
		}
		else
		{
			out.print("<script>alert('Product is not saved');window.location.href='adminzone/manageproduct.jsp';</script>");
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
